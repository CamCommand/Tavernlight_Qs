﻿Imports System.Threading
Imports System.Windows.Forms.VisualStyles.VisualStyleElement
'The player presses some keyboard input to activate a spell presumably they could also click on the icon on screen
'Then it displays the attack animation (for my purposes the 1 .gif file) and displays the name of the spell above the player
Public Class Form1
    Dim spellname = "frigo"
    Dim animation_length = 0
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
    End Sub

    Private Sub PlayAnimation()
        'this method is more to activate the timer to keep track of the animation length and to show the .gif
        animation_length = 0
        'plays the attack animation relative to where the player was when cast
        PictureBox2.Location = New Point(PictureBox1.Location.X - 400, PictureBox1.Location.Y)
        PictureBox2.Visible = True
        Timer1.Enabled = True
    End Sub
    Private Sub Form1_KeyDown(sender As Object, e As KeyEventArgs) Handles MyBase.KeyDown
        'check if the pressed key is the Enter key on the hotbar for the spell
        'I would have used a different key like F1 or 1, but I think my keyboard doesn't vibe with these imputs
        If e.KeyCode = Keys.Enter Then
            Label1.Text = "Zelek says: " + spellname
            PlayAnimation()
        End If
    End Sub
    Private Sub Form1_KeyDown_Movement(sender As Object, e As KeyEventArgs) Handles MyBase.KeyDown
        'adjust the player's position and display name based on arrow key presses
        Select Case e.KeyCode
            Case Keys.Left
                Label1.Left -= 10
                PictureBox1.Left -= 10 'Move left
            Case Keys.Right
                Label1.Left += 10
                PictureBox1.Left += 10 'Move right
            Case Keys.Up
                Label1.Top -= 10
                PictureBox1.Top -= 10 'Move up
            Case Keys.Down
                Label1.Top += 10
                PictureBox1.Top += 10 'Move down
        End Select
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        'the image change is to simulate a refreshing cooldown on the spell
        Button1.Image = Image.FromFile("E:\Code Folder\Tavernlight questions\Q_5\Q_5\Sprite\Sprite03.png")
        Label1.Text = "Zelek says: " + spellname
        PlayAnimation()

    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        'handles the animation length and text above the player
        animation_length += 1
        If animation_length = 5 Then
            PictureBox2.Visible = False
            Timer1.Enabled = False
            Label1.Text = "Zelek"
            Button1.Image = Image.FromFile("E:\Code Folder\Tavernlight questions\Q_5\Q_5\Sprite\Sprite02.png")
        End If
    End Sub

End Class