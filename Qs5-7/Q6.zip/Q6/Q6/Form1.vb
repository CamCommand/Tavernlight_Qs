﻿Imports System.Threading

Public Class Form1
    Dim last_dir = 0 'store the last direction to use for special movement ability (a tad simple)
    Private moveCount As Integer = 0
    'the video appears to me that the player is using a special movement ability where they move forward in the direction they're facing
    'it appears as if a special animation is playing, but to me it looks like the sprite is changed and is staticly being moved to the new position
    'I replicated this by pressing the Enter key for movement, in addition arrow key movements are in use to set direction
    Private Sub Form1_KeyDown_Movement(sender As Object, e As KeyEventArgs) Handles MyBase.KeyDown

        'adjust the player's position based on arrow key presses
        Select Case e.KeyCode
            Case Keys.Left
                Player.Left -= 5 'Move left
                last_dir = 0
                Player.Image = Image.FromFile("E:\Code Folder\Tavernlight questions\Q6\Q6\Sprite\Left1.png")
            Case Keys.Right
                Player.Left += 5 'Move right
                last_dir = 1
                Player.Image = Image.FromFile("E:\Code Folder\Tavernlight questions\Q6\Q6\Sprite\Right1.png")
            Case Keys.Up
                Player.Top -= 5 'Move up
                last_dir = 2
                Player.Image = Image.FromFile("E:\Code Folder\Tavernlight questions\Q6\Q6\Sprite\Up1.png")
            Case Keys.Down
                Player.Top += 5 'Move down
                last_dir = 3
                Player.Image = Image.FromFile("E:\Code Folder\Tavernlight questions\Q6\Q6\Sprite\Down1.png")
        End Select
        If e.KeyCode = Keys.Enter Then
            Timer1.Start()
        End If
    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick

        Select Case last_dir
            Case 0
                Player.Image = Image.FromFile("E:\Code Folder\Tavernlight questions\Q6\Q6\Sprite\Left2.png")
                Player.Left -= 10 'Move left
                moveCount += 1 'keep track of arbitary movement

                If moveCount >= 10 Then 'stop after it reaches destination
                    Timer1.Stop()
                    moveCount = 0
                    Player.Image = Image.FromFile("E:\Code Folder\Tavernlight questions\Q6\Q6\Sprite\Left1.png")
                End If
            Case 1
                Player.Image = Image.FromFile("E:\Code Folder\Tavernlight questions\Q6\Q6\Sprite\Right2.png")
                Player.Left += 10 'Move right
                moveCount += 1 'keep track of arbitary movement

                If moveCount >= 10 Then 'stop after it reaches destination
                    Timer1.Stop()
                    moveCount = 0
                    Player.Image = Image.FromFile("E:\Code Folder\Tavernlight questions\Q6\Q6\Sprite\Right1.png")
                End If
            Case 2
                Player.Image = Image.FromFile("E:\Code Folder\Tavernlight questions\Q6\Q6\Sprite\Up2.png")
                Player.Top -= 10 'Move up
                moveCount += 1 'keep track of arbitary movement

                If moveCount >= 10 Then 'stop after it reaches destination
                    Timer1.Stop()
                    moveCount = 0
                    Player.Image = Image.FromFile("E:\Code Folder\Tavernlight questions\Q6\Q6\Sprite\Up1.png")
                End If
            Case 3
                Player.Image = Image.FromFile("E:\Code Folder\Tavernlight questions\Q6\Q6\Sprite\Down2.png")
                Player.Top += 10 'Move down
                moveCount += 1 'keep track of arbitary movement

                If moveCount >= 10 Then 'stop after it reaches destination
                    Timer1.Stop()
                    moveCount = 0
                    Player.Image = Image.FromFile("E:\Code Folder\Tavernlight questions\Q6\Q6\Sprite\Down1.png")
                End If

        End Select




    End Sub
End Class
