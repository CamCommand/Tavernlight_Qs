﻿Imports System.IO
Public Class Form1
    Public Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        'when the button is clicked it moves to a different Y coord and returns to the X coord on the right of the box
        Select Case Button1.Location.Y
            Case 250
                Button1.Location = New Point(350, Button1.Location.Y - 100)
            Case 150
                Button1.Location = New Point(350, Button1.Location.Y - 100)
            Case 50
                Button1.Location = New Point(350, Button1.Location.Y + 200)
            Case Else
                Button1.Location = New Point(350, 250)
        End Select

    End Sub
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Timer1.Start()
    End Sub

    Public Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        'timer ticking to render the button moving accross the box on screen
        'once in the video, when the button reaches the end of the box it appears to jump to a new X coord and back to the original Y coord
        'it appears to be moving up the screen whenever it reaches the end of the box or is clicked, so I had it move up and down based on three places
        Dim posX As Integer = Button1.Location.X
        Dim posY As Integer = Button1.Location.Y

        If Button1.Location.X <= 0 Then
            posX += 400

            Select Case Button1.Location.Y
                Case 250
                    posY -= 100
                Case 150
                    posY -= 100
                Case 50
                    posY += 200
                Case Else
                    posY = 250
            End Select

        End If

        Button1.Location = New Point(posX - 10, posY)

        'Label1.Text = Button1.Location.X
        'Label2.Text = Panel1.Width
    End Sub
End Class
